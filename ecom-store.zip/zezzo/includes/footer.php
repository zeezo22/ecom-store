<footer class="page-footer">

<div class="footer-nav">
        <div class="container clearfix">

          <div class="footer-nav__col footer-nav__col--info">
            <div class="footer-nav__heading">معلومات</div>
            <ul class="footer-nav__list">
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">العلامات التجارية</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">المنتجات المحلبة</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">خدمة العملاء</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">الخصوصية &amp; تعريف الارتباط</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">عرض موقعنا</a>
              </li>
            </ul>
          </div>

          <div class="footer-nav__col footer-nav__col--whybuy">
            <div class="footer-nav__heading">لماذا تشتري منا</div>
            <ul class="footer-nav__list">
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">الشحن &amp; والاسترجاع</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">الشحن والامان</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">شهادات</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">التجارة الاخلاقية</a>
              </li>
            </ul>
          </div>

          <div class="footer-nav__col footer-nav__col--account">
            <div class="footer-nav__heading">حسابك</div>
            <ul class="footer-nav__list">
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">تسجيل دخول</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">انشاء حساب جديد</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">عرض عربتي</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">تتبع الطلب</a>
              </li>
              <li class="footer-nav__item">
                <a href="#" class="footer-nav__link">تحديث المعلومات</a>
              </li>
            </ul>
          </div>


          <div class="footer-nav__col footer-nav__col--contacts">
            <div class="footer-nav__heading">تفاصيل الاتصال </div>
            <address class="address">
            المكتب الرئسي.<br>
           المرج شارع عبدالله رفاعي.
          </address>
            <div class="phone">
              الهاتف:
              <a class="phone__number" href="tel:0123456789">01123418571</a>
            </div>
            <div class="email">
              myzo2233@gmail.com
              <a href="mailto:support@yourwebsite.com" class="email__addr">:البريد الاكتروني</a>
            </div>
          </div>>

		</div>
	</div>

	<div class="banners">
		<div class="container clearfix">

    <div class="banner-social" style="width: 100%">
            <a href="#" class="banner-social__link">
            <i class="icon-facebook"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-twitter"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-instagram"></i>
          </a>
            <a href="#" class="banner-social__link">
            <i class="icon-pinterest-circled"></i>
          </a>
          </div>

        </div>
      </div>

	<div class="page-footer__subline">
        <div class="container clearfix">

          <div class="copyright">
            &copy;  Pharmastan 2024&trade;
          </div>

          <div class="developer">
            Dev by Hamza Haridy
          </div>

          <div class="designby">
            Design by Hamza Haridy
          </div>
		</div>
	</div>
</footer>
