<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CRoboto" rel="stylesheet">
  <meta http-equiv="x-ua-compatible" content="IE=edge, chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="shortcut icon" href="https://scontent.fcai27-1.fna.fbcdn.net/v/t39.30808-6/241965982_3081659722123730_3938474110430172636_n.png?_nc_cat=107&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeHa1_Hbcb85ud1W99D640MoxD3GeKm_WGvEPcZ4qb9Ya8Xvcn_m1mVWXtMgJGA8n8lD4Fr5A7hN6GxVX-uJHRGE&_nc_ohc=ZbZV4svEuPEQ7kNvgECnMSv&_nc_zt=23&_nc_ht=scontent.fcai27-1.fna&_nc_gid=Ad_ehniRPMGgP7o8-FW4_Fv&oh=00_AYCf0mePjIylhXSOI6hXXS0q44Ge9t40gbZQGMWSS95TNg&oe=67277E90" type="image/png">
  <title>PHARMASTAN</title>
    <link href="styles/bootstrap.min.css" rel="stylesheet">
    <link href="styles/backend.css" rel="stylesheet">
    <link href="styles/style.css" rel="stylesheet">

    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
