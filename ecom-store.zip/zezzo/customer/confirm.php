<?php

session_start();

if(!isset($_SESSION['customer_email'])){

echo "<script>window.open('../checkout.php','_self')</script>";


}else {

include("includes/db.php");
include("../includes/header.php");
include("functions/functions.php");
include("includes/main.php");

if(isset($_GET['order_id'])){

$order_id = $_GET['order_id'];
$cash_on_delivery= ['payment_method'];

}
?>



<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تم تأكيد الطلب بنجاح</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<link rel="stylesheet" href="style.cs">
<script src="https://kit.fontawesome.com/5479da0db5.js" crossorigin="anonymous"></script>

<main>
    <!-- HERO -->
    <div class="nero">
      <div class="nero__heading">
        <span class="nero__bold" style='color:black;'>PHARMASTAN SHOP</span> 
      </div>
      <p class="nero__text">
      </p>
    </div>

    <div class="container">
        <h1>تم تأكيد طلبك بنجاح!</h1>

        <p>شكراً لك، <strong><?php echo "" ?></strong>، تم استلام طلبك بنجاح.</p>
        
        <div class="order-summary">
            <p><strong>رقم الطلب:</strong> #<?php echo $order_id; ?></p>
              <h4><?php echo ($cash_on_delivery =='payment_method') ?  'الدفع باستخدام البطاقة الائتمانية': 'الدفع عند الاستلام' ; ?></h4>
            </p>
        </div>

        <div class="order-note">
            <p>سيتم تجهيز طلبك قريبًا وسيتم شحنه إلى العنوان الذي قدمته.</p>
            <p>إذا كنت ترغب في متابعة حالة الطلب أو لديك أي استفسارات، يمكنك <a href="contact_us.php">الاتصال بنا</a>.</p>
        </div>

        <div class="button-container">
            <a href="../index.php" class="btn">العودة إلى الصفحة الرئيسية</a>
            <a href="../shop.php" class="btn">استمرار في التسوق</a>
        </div>
    </div>

    <style>
.nero {
    padding-top: 160px;
    padding-bottom: 140px;
    font-family: 'montserratlight', sans-serif;
    text-align: center;
    text-transform: uppercase;
    color: #FFF;
    box-shadow:5 5 5 5px ;
    background: #666 url("../images/mezo.jpg") no-repeat;
    background-size: cover;
    background-position: center;
}
/* Reset default margin and padding */
.container {
   
    text-align: center;
}

h1 {
    color: #28a745;
    margin-bottom: 20px;
}

.order-summary p {
    font-size: 18px;
    margin: 0px 0;
}

.order-note p {
    font-size: 16px;
    margin-top: px;
}

a {
    color: #007bff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

.btn {
    display: inline-block;
    background-color: #28a745;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
}

.btn:hover {
}
</style>
<br><br>
<?php
include("../includes/footer.php");
?>
</body>
</html>
<?php } ?>
