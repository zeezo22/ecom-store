<?php
$session_email = $_SESSION['customer_email'];

$select_customer = "select * from customers where customer_email='$session_email'";

$run_customer = mysqli_query($con,$select_customer);

$row_customer = mysqli_fetch_array($run_customer);

$customer_id = $row_customer['customer_id'];
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تأكيد الطلب</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="container">
        <h1>تم تأكيد طلبك بنجاح!</h1>

        <p>شكراً لك، <?php echo htmlspecialchars($name); ?>. تم استلام طلبك بنجاح. إليك تفاصيل طلبك:</p>
        
        <div class="order-details">
            <p><strong>رقم الطلب:</strong> #<?php echo $order_id; ?></p>
            <p><strong>المبلغ الإجمالي:</strong> <?php echo $total; ?> جنيه</p>
            <p><strong>طريقة الدفع:</strong> <?php echo ($payment_method == 'cash_on_delivery') ? 'الدفع عند الاستلام' : 'الدفع باستخدام البطاقة الائتمانية'; ?></p>
        </div>

        <div class="note">
            <p>ستتلقى رسالة بريد إلكتروني قريباً تحتوي على تفاصيل الشحن.</p>
            <p>في حال كان لديك أي استفسارات، لا تتردد في <a href="contact_us.php">الاتصال بنا</a>.</p>
        </div>

        <div class="button-container">
            <a href="index.php" class="btn">العودة إلى الصفحة الرئيسية</a>
        </div>
    </div>

</body>
</html>
