# Security Policy

## Reporting a Vulnerability

Contact me at : yasserdalouzi@gmail.com

